# PLSQL---Email-Package.
Procedural emailing functionality package.
